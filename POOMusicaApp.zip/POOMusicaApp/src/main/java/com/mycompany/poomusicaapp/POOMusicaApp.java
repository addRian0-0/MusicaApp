/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poomusicaapp;

import interfaces.Inicio;

/**
 *
 * @author 
 */
public class POOMusicaApp {

    public static void main(String[] args) {
        
        Inicio inicioScreen = new Inicio();
        inicioScreen.setVisible(true);
        inicioScreen.setLocationRelativeTo(null);
        
    }
}
 